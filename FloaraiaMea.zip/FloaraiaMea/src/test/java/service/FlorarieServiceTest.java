package service;

import static org.junit.jupiter.api.Assertions.*;

import model.Floare;
import model.Furnizor;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import service.FlorarieRepository;
import service.FlorarieService;

import static org.junit.jupiter.api.Assertions.*;

class FlorarieServiceTest {

    private FlorarieService florarieService;

    @BeforeEach
    void setUp() {
        florarieService = new FlorarieService(new FlorarieRepository());
    }

    @Test
    void testAdaugaFloare() {
        florarieService.adaugaFurnizor("Furnizor 1");
        florarieService.adaugaFloare("Trandafir", "Rosu", 1);

        assertEquals(1, florarieService.getFlori().size());
        assertEquals("Trandafir", florarieService.getFlori().get(0).getDenumire());
    }

    @Test
    void testAdaugaFurnizor() {
        florarieService.adaugaFurnizor("Furnizor 1");

        assertEquals(1, florarieService.getFurnizori().size());
        assertEquals("Furnizor 1", florarieService.getFurnizori().get(0).getDenumire());
    }

    @Test
    void testPersistentaDate() {
        florarieService.adaugaFurnizor("Furnizor 1");
        florarieService.adaugaFloare("Lalea", "Galbena", 1);
        florarieService.salvareDate();

        FlorarieService florarieServiceNoua = new FlorarieService(new FlorarieRepository());
        florarieServiceNoua.incarcareDate();

        assertEquals(1, florarieServiceNoua.getFlori().size());
        assertEquals("Lalea", florarieServiceNoua.getFlori().get(0).getDenumire());
    }
}