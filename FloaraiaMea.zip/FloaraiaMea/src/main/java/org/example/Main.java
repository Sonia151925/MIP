package org.example;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import service.FlorarieService;
import service.FlorarieRepository;
import model.Floare;
import model.Furnizor;

public class Main extends Application
{

    private FlorarieService florarieService = new FlorarieService(new FlorarieRepository());
    private TextField denumireFloareField = new TextField();
    private TextField culoareFloareField = new TextField();
    private ComboBox<Furnizor> furnizorComboBox = new ComboBox<>();
    private TextField denumireFurnizorField = new TextField();

    public static void main(String[] args)
    {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage)
    {
        florarieService.incarcareDate();

        VBox vbox = new VBox(10);
        vbox.setPadding(new javafx.geometry.Insets(20));

        HBox floareForm = createFloareForm();
        HBox furnizorForm = createFurnizorForm();

        ListView<Floare> listaFlori = new ListView<>();
        listaFlori.getItems().addAll(florarieService.getFlori());

        ListView<Furnizor> listaFurnizori = new ListView<>();
        listaFurnizori.getItems().addAll(florarieService.getFurnizori());

        Button salveazaButton = createSaveButton(listaFlori, listaFurnizori);

        vbox.getChildren().addAll(floareForm, furnizorForm, salveazaButton, listaFlori, listaFurnizori);

        Scene scene = new Scene(vbox, 600, 400);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Aplicație Florărie");
        primaryStage.show();
    }

    private HBox createFloareForm()
    {
        HBox floareForm = new HBox(10);
        floareForm.setPadding(new javafx.geometry.Insets(10));

        Label denumireLabel = new Label("Denumire floare:");
        Label culoareLabel = new Label("Culoare:");

        Button adaugaFloareButton = new Button("Adaugă Floare");
        adaugaFloareButton.setOnAction(e -> {
            String denumire = denumireFloareField.getText();
            String culoare = culoareFloareField.getText();
            Furnizor furnizorSelectat = furnizorComboBox.getValue();

            if (denumire.isEmpty() || culoare.isEmpty() || furnizorSelectat == null) {
                showAlert("Eroare", "Toate câmpurile trebuie completate!");
                return;
            }

            florarieService.adaugaFloare(denumire, culoare, furnizorSelectat.getIdFurnizor());
            denumireFloareField.clear();
            culoareFloareField.clear();
        });

        floareForm.getChildren().addAll(denumireLabel, denumireFloareField, culoareLabel, culoareFloareField, furnizorComboBox, adaugaFloareButton);
        return floareForm;
    }

    private HBox createFurnizorForm() {
        HBox furnizorForm = new HBox(10);
        furnizorForm.setPadding(new javafx.geometry.Insets(10));

        Label denumireFurnizorLabel = new Label("Denumire furnizor:");

        Button adaugaFurnizorButton = new Button("Adaugă Furnizor");
        adaugaFurnizorButton.setOnAction(e -> {
            String denumire = denumireFurnizorField.getText();
            if (denumire.isEmpty()) {
                showAlert("Eroare", "Denumirea furnizorului nu poate fi goală!");
                return;
            }

            florarieService.adaugaFurnizor(denumire);
            furnizorComboBox.getItems().setAll(florarieService.getFurnizori());
            denumireFurnizorField.clear();
        });

        furnizorForm.getChildren().addAll(denumireFurnizorLabel, denumireFurnizorField, adaugaFurnizorButton);
        return furnizorForm;
    }

    private Button createSaveButton(ListView<Floare> listaFlori, ListView<Furnizor> listaFurnizori) {
        Button salveazaButton = new Button("Salvează datele");
        salveazaButton.setOnAction(e -> {
            florarieService.salvareDate();
            listaFlori.getItems().setAll(florarieService.getFlori());
            listaFurnizori.getItems().setAll(florarieService.getFurnizori());
        });
        return salveazaButton;
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
