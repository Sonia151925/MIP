package model;

public class Furnizor {
    private int idFurnizor;
    private String denumire;

    public Furnizor(int idFurnizor, String denumire) {
        this.idFurnizor = idFurnizor;
        this.denumire = denumire;
    }

    public int getIdFurnizor() {
        return idFurnizor;
    }

    public void setIdFurnizor(int idFurnizor) {
        this.idFurnizor = idFurnizor;
    }

    public String getDenumire() {
        return denumire;
    }

    public void setDenumire(String denumire) {
        this.denumire = denumire;
    }

    @Override
    public String toString()
    {
        return "Furnizor{id=" + idFurnizor + ", denumire='" + denumire + "'}";
    }
}
