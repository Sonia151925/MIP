package model;

public class Floare
{
    private int idFloare;
    private String denumire;
    private String culoare;
    private int idFurnizor;

    public Floare(int idFloare, String denumire, String culoare, int idFurnizor) {

        this.idFloare = idFloare;
        this.denumire = denumire;
        this.culoare = culoare;
        this.idFurnizor = idFurnizor;
    }

    public int getIdFloare()
    {
        return idFloare;
    }

    public void setIdFloare(int idFloare)
    {
        this.idFloare = idFloare;
    }

    public String getDenumire()
    {
        return denumire;
    }

    public void setDenumire(String denumire)
    {
        this.denumire = denumire;
    }

    public String getCuloare()
    {
        return culoare;
    }

    public void setCuloare(String culoare)
    {
        this.culoare = culoare;
    }

    public int getIdFurnizor()
    {
        return idFurnizor;
    }

    public void setIdFurnizor(int idFurnizor)
    {
        this.idFurnizor = idFurnizor;
    }

    @Override
    public String toString()
    {
        return "Floare{id=" + idFloare + ", denumire='" + denumire + "', culoare='" + culoare + "', furnizorId=" + idFurnizor + "}";
    }
}
