package interfaces;

import model.Floare;
import model.Furnizor;

import java.util.List;

public interface IFlorarieRepository

{
    void salvareDate(List<Floare> flori, List<Furnizor> furnizori);
    void incarcareDate(List<Floare> flori, List<Furnizor> furnizori);
}
