package interfaces;

import model.Floare;
import model.Furnizor;

import java.util.List;

public interface IFlorarieService
{
    void adaugaFloare(String denumire, String culoare, int idFurnizor);
    void adaugaFurnizor(String denumire);
    List<Floare> getFlori();
    List<Furnizor> getFurnizori();
}
