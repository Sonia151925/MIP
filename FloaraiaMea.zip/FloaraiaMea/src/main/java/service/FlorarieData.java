package service;

import model.Floare;
import model.Furnizor;

import java.util.List;

public class FlorarieData
{
    private List<Floare> flori;
    private List<Furnizor> furnizori;

    public FlorarieData(List<Floare> flori, List<Furnizor> furnizori)
    {
        this.flori = flori;
        this.furnizori = furnizori;
    }

    public List<Floare> getFlori()
    {
        return flori;
    }

    public List<Furnizor> getFurnizori()
    {
        return furnizori;
    }
}
