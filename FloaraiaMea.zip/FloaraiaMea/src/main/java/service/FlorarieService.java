package service;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import interfaces.IFlorarieService;
import interfaces.IFlorarieRepository;
import model.Floare;
import model.Furnizor;

import java.io.*;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class FlorarieService implements IFlorarieService
{
    private List<Floare> flori = new ArrayList<>();
    private List<Furnizor> furnizori = new ArrayList<>();
    private IFlorarieRepository florarieRepository;

    public FlorarieService(IFlorarieRepository florarieRepository)
    {
        this.florarieRepository = florarieRepository;
    }

    @Override
    public void adaugaFloare(String denumire, String culoare, int idFurnizor)
    {
        int idFloare = flori.size() + 1;
        Floare floare = new Floare(idFloare, denumire, culoare, idFurnizor);
        flori.add(floare);
    }

    @Override
    public void adaugaFurnizor(String denumire)
    {
        int idFurnizor = furnizori.size() + 1;
        Furnizor furnizor = new Furnizor(idFurnizor, denumire);
        furnizori.add(furnizor);
    }

    @Override
    public List<Floare> getFlori()
    {
        return flori;
    }

    @Override
    public List<Furnizor> getFurnizori()
    {
        return furnizori;
    }

    public void salvareDate()
    {
        florarieRepository.salvareDate(flori, furnizori);
    }

    public void incarcareDate()
    {
        florarieRepository.incarcareDate(flori, furnizori);
    }
}
