package service;

import com.google.gson.Gson;
import interfaces.IFlorarieRepository;
import model.Floare;
import model.Furnizor;

import java.io.*;
import java.util.List;

public class FlorarieRepository implements IFlorarieRepository
{

    @Override
    public void salvareDate(List<Floare> flori, List<Furnizor> furnizori)
    {
        try (Writer writer = new FileWriter("florarie_data.json"))
        {
            Gson gson = new Gson();
            writer.write(gson.toJson(new FlorarieData(flori, furnizori)));
        } catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    @Override
    public void incarcareDate(List<Floare> flori, List<Furnizor> furnizori)
    {
        try (Reader reader = new FileReader("florarie_data.json"))
        {
            Gson gson = new Gson();
            FlorarieData data = gson.fromJson(reader, FlorarieData.class);
            flori.addAll(data.getFlori());
            furnizori.addAll(data.getFurnizori());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
